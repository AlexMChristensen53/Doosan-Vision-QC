# ======================================================
# main.py — FULL QC PIPELINE (LIVE OAK-D)
# Debug-visning + print identisk med alle QC testmoduler
# ======================================================

import cv2 as cv
import numpy as np
from pathlib import Path
import sys

# -------------------------------------------
# PATH SETUP
# -------------------------------------------
ROOT = Path(__file__).resolve().parent
sys.path.append(str(ROOT))

# QC modules
from qc_preprocess import QCPreprocess
from qc_form import QCForm
from qc_size import QCSize
from qc_color import QCColor
from qc_special import QCSpecial
from qc_evaluate import QCEvaluate

# Camera
from qc_vision_camera import OakCamera


# ------------------------------------------------------
# QC MODULE INSTANCES (samme settings som testfilerne)
# ------------------------------------------------------
qc_form = QCForm(
    min_area=1500,
    min_aspect=2.0,
    max_aspect=7.0,
    min_solidity=0.88,
    min_extent=0.90
)

qc_size = QCSize(
    mm_per_pixel=0.5098,
    expected_width_mm=100.0,
    expected_height_mm=25.0,
    tolerance_width_mm=5.0,
    tolerance_height_mm=3.0
)

qc_color = QCColor(
    reference_lab=np.array([107.30, 187.07, 160.88]),
    tolerance_dE=25.0
)

qc_special = QCSpecial(
    expected_hole_count=2,
    min_hole_area=50
)

qc_eval = QCEvaluate()

# ------------------------------------------------------
# CAMERA INIT
# ------------------------------------------------------
cam = OakCamera((1920, 1080))

# What you display (not used for robot)
DISPLAY_W = 640
DISPLAY_H = 400

# ------------------------------------------------------
# MAIN LOOP
# ------------------------------------------------------
while True:

    frame = cam.get_frame()
    if frame is None:
        continue

    # --------------------------------------------------
    # 1) PREPROCESS
    # --------------------------------------------------
    mask, gray, thresh, edges, debug = QCPreprocess(frame)

    # --------------------------------------------------
    # 2) EVALUATE MODULES
    # --------------------------------------------------
    form_results    = qc_form.evaluate_all(mask)
    size_results    = qc_size.evaluate_all(form_results)
    color_results   = qc_color.evaluate_all(frame, form_results)
    special_results = qc_special.evaluate_all(mask, form_results)

    final_results = qc_eval.combine(
        form_results,
        size_results,
        color_results,
        special_results
    )

    # --------------------------------------------------
    # 3) DRAW OVERALL OVERLAY
    # --------------------------------------------------
    overlay = qc_eval.draw_overlay(frame, form_results, final_results)
    preview5 = cv.resize(overlay, (DISPLAY_W, DISPLAY_H))
    cv.imshow("QC – overlay", preview5)

    # --------------------------------------------------
    # 4) DEBUG WINDOWS (IDENTISK MED TEST-MODULERNE)
    # --------------------------------------------------

    # FORM (same as test_qc_form.py)
    form_bgr = cv.cvtColor(mask, cv.COLOR_GRAY2BGR)
    dbg_form = qc_form.draw_overlay(form_bgr, form_results)
    preview1 = cv.resize(dbg_form, (DISPLAY_W, DISPLAY_H))
    cv.imshow("QC – FORM", preview1)

    # SIZE (same as qc_size_test.py)
    dbg_size = qc_size.draw_overlay(form_bgr, form_results, size_results)
    preview2 = cv.resize(dbg_size, (DISPLAY_W, DISPLAY_H))
    cv.imshow("QC – size", preview2)

    # COLOR (same as qc_color_test.py)
    dbg_color = qc_color.draw_overlay(frame.copy(), form_results, color_results)
    preview3 = cv.resize(dbg_color, (DISPLAY_W, DISPLAY_H))
    cv.imshow("QC – color", preview3)

    # SPECIAL (same as qc_special_test.py)
    spec_bgr = cv.cvtColor(mask, cv.COLOR_GRAY2BGR)
    dbg_special = qc_special.draw_overlay(spec_bgr, form_results, special_results)
    preview4 = cv.resize(dbg_special, (DISPLAY_W, DISPLAY_H))
    cv.imshow("QC – special", preview4)

    # --------------------------------------------------
    # 5) KEYBOARD INPUT
    # --------------------------------------------------
    key = cv.waitKey(1) & 0xFF

    if key == ord('q'):
        break

    # ---------- PRINTS IDENTICAL TO TEST SCRIPTS ----------
    if key == ord('u'):   # FORM
        print("\n--- QC FORM (px) ---")
        for i, r in enumerate(form_results):
            print(f"Objekt {i+1}:")
            print("  area        :", r["area"])
            print("  aspect_ratio:", r["aspect_ratio"])
            print("  solidity    :", r["solidity"])
            print("  extent      :", r["extent"])
            print("  valid       :", r["valid"])
            print("  reason      :", r["reason"])
            print()

    elif key == ord('i'):   # SIZE
        print("\n--- QC SIZE (mm) ---")
        for i, r in enumerate(size_results):
            print(f"Objekt {i+1}: width={r['width_mm']:.2f}mm, "
                  f"height={r['height_mm']:.2f}mm, valid_size={r['valid_size']}, "
                  f"reason={r['reason']}")

    elif key == ord('o'):   # COLOR
        print("\n--- QC COLOR (LAB + ΔE) ---")
        for i, r in enumerate(color_results):
            print(f"Objekt {i+1}: valid_color={r['valid_color']}, "
                  f"ΔE={r['deltaE']:.2f}, reason={r['reason']}")

    elif key == ord('p'):   # SPECIAL
        print("\n--- QC SPECIAL (huller) ---")
        for i, r in enumerate(special_results):
            print(f"Objekt {i+1}: holes={r['hole_count']} → valid={r['valid_special']}, "
                  f"reason={r['reason']}")

cv.destroyAllWindows()